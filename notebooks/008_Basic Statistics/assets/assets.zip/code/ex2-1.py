import pandas as pd
data=pd.read_csv('ex2-1.csv')

data.number.describe()